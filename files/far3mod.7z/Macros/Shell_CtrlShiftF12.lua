Macro {
  description="Запустить Far от имени «Trusted Installer»";
  area="Shell"; key="CtrlShiftF12";
  action=function()
   Keys"CtrlG \" % f a r h o m e % \\ u t i l s \\ N S u d o L C . e x e \" Space - U : T Space - P : E Space \" % f a r h o m e % \\ F a r . e x e \" Enter";
  end;
}
