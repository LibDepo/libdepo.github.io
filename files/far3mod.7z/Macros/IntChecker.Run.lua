﻿-- Integrity Checker by Ariman

-- Этот сервисный скрипт решает задачи не решаемые плагином - например создание
-- файлов хэшей для произвольных UNC объектов в данный момент находящихся вне
-- текущей активной панели Far, рекурсивного счёта хэшей для случаев вида "на
-- активной панели выделены файлы и каталоги. Посчитать для них хэши с учётом
-- вложенных каталогов, остальное игнорировать." при разных способах постановки
-- задачи - либо считать на текушей панели, либо ввести UNC путь и считать в его
-- пределах, хотя на панели есть выделенные объекты за пределами UNC пути,
-- диагностики некоторых ошибок, в.ч. ошибочного переключения клавиатуры с
-- вводом неправильных команд, вывод хэшей в формате BSD UNIX, а не только GNU,
-- запись файлов хэшей по UNC пути в родительский каталог объекта...

-- Макросы скрипта специально назначены на Alt-H/Alt-G чтобы не перекрывался
-- функционал хоткея  Ctrl-H - 'Убрать/показать файлы с атрибутом "Скрытый" и
-- "Системный"' Far-а (см. Справку Far-а: "Клавиатурные команды" - "Команды
-- управления панелями" раздел "Команды файловой панели") и не конфликтовали с
-- другими встроенными командами Far-а.

-- P.S.

-- GUI диалога нет, и в обозримом будущем его добавление не планируется.

-- VictorVG @ VikSoft.Ru/

-- v1.0 - initial version
-- Wds Jan 15 02:16:30 +0300 2014
-- v1.1 - refactoring
-- Mon Jun 15 06:32:20 +0300 2015
-- v1.1.1 - refactoring
-- Tue Jun 16 23:25:04 +0300 2015
-- v1.2 - рефакторинг
-- Mon Jun 22 05:40:42 +0300 2015
-- v1.2.1 - рефакторинг
-- Thu Aug 04 15:09:30 +0300 2016
-- v1.2.2 - добавлена поддержка SHA3-512
-- 07.11.2017 17:09:21 +0300
-- v1.3 - рефакторинг и срабатывание макроса на MsLClick по Double Click
-- 17.11.2017 16:12:57 +0300
-- v1.3.1 - рефакторинг
-- 17.11.2017 20:53:52 +0300
-- v1.4 - добавлен новый макрос на Alt-G - "Integrity Checker: calc hash for
-- the file under cursor" умеющий выводить хэш на экран, в буфер обмена ОС или
-- в хэш файл с именем файла и расширением зависящим от алгоритма в форматах
-- BSD UNIX или GNU Linux. Макрос написан в виде пошагового мастера с выводом
-- подсказок в заголовке диалога ввода. Одно символьные хоткеи команд мастера
-- указаны перед ":" или "-", например 1:CRC32,  G - GNU. Доступные команды в
-- списке разделены ";". Это сделано для снижения риска ошибок, и справка по
-- командам стала не нужна.
-- 18.03.2019 02:40:23 +0300
-- v1.4.1 - Исправим ошибку с пробелами в путях
-- 18.03.2019 10:35:23 +0300
-- v1.4.2 - уточнение v1.4.1
-- 18.03.2019 13:48:54 +0300
-- v1.4.3 - при не пустой командной строке если курсор стоит на хэше спросим
-- оператора что делать? Ok - выполним командную строку, Canсel - проверим хэш.
-- 23.03.2019 22:41:07 +0300
-- v1.4.4 - мелкий рефакторинг, вопрос к пользователю задаётся по русски,
-- а чтобы LuaCheck не ругался на длинную строку в mf.msgbox вынесем сообщение
-- в отдельный оператор local так, чтобы вывелась только одна строка
-- 22.04.2019 17:53:12 +0300
-- v1.5.0 - рефакторинг, макрос Integrity Checker: calc hash for the file under
-- cursor переписано с использованием chashex(), реализован расчёт хешей для всех
-- или выбранных файлов в текущем каталоге;
-- 02.10.2019 08:58:55 +0300
-- v1.6.0 - расчёт хэшей для указанного пользователем файла или дерева каталогов, рефакторинг;
-- 07.10.2019 22:00:27 +0300
-- v1.7.0 - считаем хэши для всех файлов в локальном каталоге и его подкаталогах, рефакторинг;
-- 09.10.2019 19:01:24 +0300
-- v1.8.0 - автовыбора режима счёта "папка/файл" для UNC пути с коррекцией ошибок ввода и
-- проверкой их существования, хэши сохраняются в обрабатываемый UNC каталог, рефакторинг.
-- 13.10.2019 00:02:14 +0300
-- v1.8.1 - возвращаемый хэш всегда строка, все сообщения на английском, по умолчанию Target
-- всегда экран, рефакторинг;
-- 13.10.2019 16:58:01 +0300
-- v1.9 - вместо chashex() используем chex(), расширенная диагностика и исправление ошибок оператора.
-- 12.11.2019 22:57:42 +0300
-- v1.9.1 - "Integrity Checker: calculate hash for ..." обработка нажатия ESC, уточнение v1.9
-- 27.01.2020 02:59:44 +0300
-- v2.0 - chex() v2.1, пути в стиле Windows/UNIX, новая диагностика ошибок, требует IntChecker v2.80, рефакторинг
-- 09.03.2020 06:50:43 +0300
--
local ICId,ICMID = "E186306E-3B0D-48C1-9668-ED7CF64C0E65","A22F9043-C94A-4037-845C-26ED67E843D1";
local Mask = "/.+\\.(md5|sfv|sha(1|3|256|512)|wrpl)/i";
local MsB,MsF = Mouse.Button,Mouse.EventFlags;
local Msg = "The command line is not empty, but a hash file is under the cursor.\nWhat to do? Command: Ok or Verification: Cancel";
local function chex (pth,hn,fh,ft,r,sld)
local ds,ec,fc,fl,pt,rn,rt,s0 = "",0,0,4,"",0,"","";
pth = tostring(pth)
if tostring(r):find("true") then r = true else r = false end;
if tostring(ft):find("true") then ft = true else ft = false end;
 if #mf.fsplit(pth,1) == 0 then
  if pth:find("\\",1,1) then pth = pth:sub(2) elseif pth:find("/",1,1) then pth = pth:sub(2) end
  pt = APanel.Path.."\\"..pth
 else
  pt = pth
 end
 pt = mf.fsplit(pt,1)..mf.fsplit(pt,2)..mf.fsplit(pt,4)..mf.fsplit(pt,8)
 if mf.fexist(pth) then
  local f = mf.testfolder(pth)
  if f == 2 then
    local df = ""
    if r then fl = 6 else fl = 4 end;
     pt = pth
     if sld then df = win.GetFileInfo(pt).FileName.."\\" else df = "" end
     far.RecursiveSearch(""..pt.."","*>>D",function (itm,fp,hn,ft)
     rt = tostring(Plugin.SyncCall(ICId,"gethash",""..hn.."",""..fp.."",true));
     if rt == "userabort" then
      rn = 6
      return rn;
     else
      if rt ~= "false" and #rt ~= 0 then
       fc = fc + 1
       if fp:find("\\\\") then fp = fp:sub(#pt + 1) else fp = fp:sub(#pt + 2) end
       fp = df..fp
       if tostring(fh):find("true") then fp = fp:gsub("\\","/") end
       if ft then s0 = s0..hn.." ("..fp..") = "..rt.."\n" else s0 = s0..rt.." *"..fp.."\n" end
      else
       if f == -1 then
        rn = math.max(rn,4)
        ec = ec + 1
       elseif #rt == 0 then
        rn = math.max(rn,3)
        ec = ec + 1
       end
      end
     end
    end,fl,hn,ft)
    ds = pth
  else
   local obj = win.GetFileInfo(pt)
   if not not obj then
    rt = tostring(Plugin.SyncCall(ICId,"gethash",""..hn.."",""..pt.."",true));
    if rt == "userabort" then
     rn = 6
     ec = 1
    else
     if rt ~= "false" and #rt ~= 0 then
      fc = 1
      if ft then s0 = hn.." ("..obj.FileName..") = "..rt else s0 = rt.." *"..obj.FileName end;
      ds = pt:sub(1,#pt - #obj.FileName - 1)
     elseif #rt == 0 then
      rn = 3
      ec = 1
     end
    end
   end
  end
 end
 local ret = {RetCode = rn, FileCnt = fc, ErrCnt = ec, HashSumm = mf.trim(s0), DirSW = ds }
 return ret
end;

Macro{
  id = "C7BD288F-E03F-44F1-8E43-DC7BC7CBE4BA";
  area = "Shell";
  key = "Enter NumEnter MsM1Click";
  description = "Integrity Checker: проверка хэш-сумм.";
  priority = 60;
  flags = "EnableOutput";
  condition = function() return (mf.fmatch(APanel.Current,Mask)==1 and not (MsB==0x0001 and MsF==0x0001)) end;
  action = function()
  if not CmdLine.Empty then
   if mf.msgbox("Question to the user:",Msg,0x00020000) == 1 then
    Keys("Enter");
   else
    Far.DisableHistory(-1) Plugin.Command(ICId,APanel.Current);
   end;
  else
   Far.DisableHistory(-1) Plugin.Command(ICId,APanel.Current);
  end;
 end;
}
