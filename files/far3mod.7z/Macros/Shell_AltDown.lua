Macro {
  description="Открыть «Историю комманд».";
  area="Shell"; key="AltDown";
  flags="";
  code="Keys(\"AltF8\")";
}
