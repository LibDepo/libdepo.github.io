Macro {
  description="NetBox: вызов Putty";
  area="Shell"; key="CtrlP";
  flags="NoFilePanels";
  code="Keys(\"F11 t p\")";
}
