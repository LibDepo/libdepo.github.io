Macro {
  description="Архивировать выбранное консольным 7z.";
  area="Shell"; key="CtrlShiftF1";
  flags="";
  code="Keys(\"ShiftF1 Down Enter Up Left Left Enter Up Enter\")";
}
