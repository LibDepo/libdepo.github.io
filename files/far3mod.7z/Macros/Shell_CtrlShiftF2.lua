Macro {
  description="Архивировать выбранное консольным RAR.";
  area="Shell"; key="CtrlShiftF2";
  flags="";
  code="Keys(\"ShiftF1 Down Enter Up Left Left Enter Down Enter\")";
}
