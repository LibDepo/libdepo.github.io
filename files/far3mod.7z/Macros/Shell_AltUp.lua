Macro {
  description="Открыть «Историю папок».";
  area="Shell"; key="AltUp";
  flags="";
  code="Keys(\"AltF12\")";
}
