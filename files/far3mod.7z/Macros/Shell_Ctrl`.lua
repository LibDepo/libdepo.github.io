Macro {
  description="Открыть «Ссылки на папки».";
  area="Shell"; key="Ctrl`";
  flags="";
  code="Keys(\"F9 AltR AltK\")";
}
